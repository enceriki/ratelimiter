<?php

declare(strict_types=1);

namespace RateLimiter;

// ═══════════════════════════════════════════════════════════
//  CONTRACT
// ═══════════════════════════════════════════════════════════

interface StorageInterface
{
    public function get(string $key): ?array;
    public function set(string $key, array $data, int $ttl): void;
    public function delete(string $key): void;
}


// ═══════════════════════════════════════════════════════════
//  FILE STORAGE
//  ✅ FIX 1: Race condition — flock() eksklusif per key
//  ✅ FIX 2: Storage bloat — Garbage Collection otomatis
// ═══════════════════════════════════════════════════════════

class FileStorage implements StorageInterface
{
    private string $dir;

    /**
     * @param string $dir       Direktori penyimpanan (dibuat otomatis)
     * @param int    $gcDivisor Probabilitas GC: 1/$gcDivisor per request.
     *                          Default 100 = ~1% chance tiap request.
     *                          Set 0 untuk nonaktifkan GC otomatis.
     * @param int    $maxFiles  ✅ FIX 5: Batas maksimum file yang diizinkan.
     *                          Jika direktori sudah penuh, set() ditolak
     *                          dan GC dipaksa berjalan.
     *                          Default 10.000. Set 0 = tidak ada batas.
     *
     * ⚠️  Peringatan DoS FileStorage:
     *   Penyerang yang membanjiri sistem dengan identifier unik dapat
     *   membuat ribuan file sebelum GC sempat membersihkan.
     *   Rekomendasi untuk production:
     *     1. Gunakan RedisStorage (TTL dikelola Redis otomatis)
     *     2. Set maxFiles ke nilai yang sesuai kapasitas disk
     *     3. Jalankan GC via cron tiap 5 menit:
     *        * /5 * * * * php -r "
     *          require '/var/www/RateLimiter/autoload.php';
     *          (new RateLimiter\FileStorage('/var/www/tmp/rl', gcDivisor: 0))->gc();"
     */
    public function __construct(
        string $dir = '',
        private int $gcDivisor = 100,
        private int $maxFiles  = 10_000
    ) {
        $this->dir = rtrim($dir ?: sys_get_temp_dir() . '/ratelimiter', '/');

        if (!is_dir($this->dir)) {
            mkdir($this->dir, 0700, true);
        }

        // Proteksi: blokir akses web langsung ke folder ini
        $htaccess = $this->dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "Deny from all\nOptions -Indexes\n");
        }
    }

    // ── ATOMIC READ dengan flock ────────────────────────────────
    //
    // PERBAIKAN RACE CONDITION:
    // Masalah lama: get() dan set() adalah dua operasi terpisah.
    //   → Thread A baca count=59, Thread B baca count=59,
    //     keduanya lolos → total 61 request, limit seharusnya 60.
    //
    // Solusi: file .lock terpisah per key + LOCK_EX.
    //   → Thread A ambil LOCK_EX → baca → tulis → lepas lock.
    //   → Thread B menunggu di flock() hingga Thread A selesai.
    //   → Tidak ada dua thread yang bisa baca+tulis bersamaan.
    //
    // Trade-off: throughput turun ~15-30% karena serialisasi
    // per key. Untuk traffic tinggi, gunakan RedisStorage.

    public function get(string $key): ?array
    {
        // GC probabilistik: ~1% dari request (tidak blokir user).
        // ✅ FIX 3: random_int() dibungkus try-catch.
        // Pada environment terbatas (misal container minimal), sumber
        // entropy bisa tidak tersedia dan random_int() throw Exception.
        // Fallback ke mt_rand() yang tidak perlu sumber entropy OS.
        if ($this->gcDivisor > 0) {
            try {
                $chance = random_int(1, $this->gcDivisor);
            } catch (\Exception) {
                $chance = mt_rand(1, $this->gcDivisor);
            }
            if ($chance === 1) {
                $this->gc();
            }
        }

        $path     = $this->path($key);
        $lockPath = $path . '.lock';

        // Buka/buat lock file (mode 'c' = buat jika belum ada, tidak truncate)
        $lock = fopen($lockPath, 'c');
        if ($lock === false) {
            return null;
        }

        // LOCK_EX = exclusive lock; proses lain harus tunggu
        if (!flock($lock, LOCK_EX)) {
            fclose($lock);
            return null;
        }

        try {
            if (!file_exists($path)) {
                return null;
            }

            $raw  = file_get_contents($path);
            $data = $raw !== false ? json_decode($raw, true) : null;

            if (!is_array($data)) {
                return null;
            }

            // Cek TTL
            if (isset($data['_expires']) && time() > $data['_expires']) {
                @unlink($path);
                return null;
            }

            unset($data['_expires']);
            return $data;

        } finally {
            flock($lock, LOCK_UN); // Lepaskan lock SETELAH selesai baca
            fclose($lock);
        }
    }

    public function set(string $key, array $data, int $ttl): void
    {
        // ✅ FIX 5: Cegah DoS dengan membatasi jumlah file.
        // Jika direktori sudah mencapai batas, paksa GC dulu.
        // Jika setelah GC masih penuh, tolak write baru.
        if ($this->maxFiles > 0 && $this->count() >= $this->maxFiles) {
            $this->gc(); // paksa bersihkan dulu
            if ($this->count() >= $this->maxFiles) {
                // Masih penuh setelah GC — tolak untuk cegah disk penuh
                error_log('[RateLimiter:FileStorage] Batas file tercapai (' . $this->maxFiles . '). Write ditolak untuk key: ' . $key);
                return;
            }
        }

        $path     = $this->path($key);
        $lockPath = $path . '.lock';

        $lock = fopen($lockPath, 'c');
        if ($lock === false) {
            return;
        }

        if (!flock($lock, LOCK_EX)) {
            fclose($lock);
            return;
        }

        try {
            $data['_expires'] = time() + $ttl;
            $tmp              = $path . '.tmp';

            // Tulis ke file sementara lalu rename (atomic di sistem POSIX)
            file_put_contents($tmp, json_encode($data), LOCK_EX);
            rename($tmp, $path);

        } finally {
            flock($lock, LOCK_UN); // Lepaskan lock SETELAH selesai tulis
            fclose($lock);
        }
    }

    public function delete(string $key): void
    {
        $path     = $this->path($key);
        $lockPath = $path . '.lock';

        if (file_exists($path))     { @unlink($path); }
        if (file_exists($lockPath)) { @unlink($lockPath); }
    }

    // ── GARBAGE COLLECTION ─────────────────────────────────────
    //
    // PERBAIKAN STORAGE BLOAT:
    // Masalah lama: file expired hanya dihapus saat diakses.
    //   → Penyerang bisa buat ribuan identifier unik → ribuan file.
    //   → Direktori membengkak → filesystem dan glob() lambat.
    //
    // Solusi: gc() dipanggil probabilistik (default ~1% per request).
    // Untuk kontrol penuh, set gcDivisor=0 dan panggil gc() via cron:
    //   */5 * * * * php -r "require 'autoload.php';
    //     (new RateLimiter\FileStorage('/path/tmp'))->gc();"

    public function gc(): void
    {
        $now   = time();
        $files = glob($this->dir . '/*.json');

        if ($files === false) {
            return;
        }

        foreach ($files as $path) {
            // Skip file yang baru dimodifikasi (kemungkinan masih aktif)
            if (@filemtime($path) > $now) {
                continue;
            }

            $raw  = @file_get_contents($path);
            $data = $raw !== false ? json_decode($raw, true) : null;

            // Hapus jika tidak bisa dibaca atau sudah expired
            if (!is_array($data) || (isset($data['_expires']) && $now > $data['_expires'])) {
                @unlink($path);
                $lock = $path . '.lock';
                if (file_exists($lock)) {
                    @unlink($lock);
                }
            }
        }
    }

    /** Jumlah file aktif (berguna untuk monitoring/alerting). */
    public function count(): int
    {
        $files = glob($this->dir . '/*.json');
        return $files !== false ? count($files) : 0;
    }

    private function path(string $key): string
    {
        $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
        return $this->dir . '/' . $safe . '.json';
    }
}


// ═══════════════════════════════════════════════════════════
//  REDIS STORAGE  (Direkomendasikan untuk production)
// ═══════════════════════════════════════════════════════════

class RedisStorage implements StorageInterface
{
    private \Redis $redis;

    public function __construct(\Redis $redis)
    {
        $this->redis = $redis;
    }

    public static function connect(
        string $host     = '127.0.0.1',
        int    $port     = 6379,
        string $password = '',
        int    $database = 0
    ): self {
        $redis = new \Redis();
        $redis->connect($host, $port, 2.0); // timeout 2 detik

        if ($password !== '') {
            $redis->auth($password);
        }
        if ($database !== 0) {
            $redis->select($database);
        }

        return new self($redis);
    }

    public function get(string $key): ?array
    {
        $raw = $this->redis->get($key);
        if ($raw === false || $raw === null) {
            return null;
        }

        $data = json_decode($raw, true);
        return is_array($data) ? $data : null;
    }

    public function set(string $key, array $data, int $ttl): void
    {
        // Redis EX = detik — atomic dengan SET + EXPIRE
        $this->redis->setEx($key, $ttl, json_encode($data));
    }

    public function delete(string $key): void
    {
        $this->redis->del($key);
    }
}


// ═══════════════════════════════════════════════════════════
//  APCU STORAGE  (In-memory, satu server)
//
//  ✅ FIX 2: Race condition ApcuStorage.
//
//  Masalah lama: apcu_fetch() + apcu_store() dua operasi
//  terpisah — tidak atomik. Dua request bersamaan bisa baca
//  nilai yang sama, keduanya lolos, counter tidak akurat.
//
//  Solusi: set() menggunakan apcu_delete() + apcu_entry()
//  agar callback selalu berjalan di dalam APCu write-lock.
//
//  ⚠️  Batasan yang masih ada:
//    - ApcuStorage tetap hanya cocok untuk single-server.
//    - Jendela atomicity antara delete → entry sangat kecil
//      tapi secara teori masih bisa race pada traffic ekstrem.
//    - Untuk production multi-server: WAJIB pakai RedisStorage.
// ═══════════════════════════════════════════════════════════

class ApcuStorage implements StorageInterface
{
    public function __construct()
    {
        if (!extension_loaded('apcu') || !apcu_enabled()) {
            throw new \RuntimeException('Ekstensi APCu tidak tersedia atau tidak aktif.');
        }
    }

    public function get(string $key): ?array
    {
        $raw = apcu_fetch($key, $success);
        if (!$success || !is_array($raw)) {
            return null;
        }
        return $raw;
    }

    public function set(string $key, array $data, int $ttl): void
    {
        if (function_exists('apcu_entry')) {
            // apcu_entry() menjalankan callback di dalam APCu write-lock.
            // Namun karena kita perlu overwrite (bukan hanya "isi jika kosong"),
            // kita delete dulu agar callback pasti dipanggil.
            apcu_delete($key);
            apcu_entry($key, fn() => $data, $ttl);
        } else {
            // Fallback untuk PHP < 7.2 — tidak atomik, gunakan Redis
            apcu_store($key, $data, $ttl);
        }
    }

    public function delete(string $key): void
    {
        apcu_delete($key);
    }
}


// ═══════════════════════════════════════════════════════════
//  HYBRID STORAGE  (Redis utama + APCu/File fallback)
//
//  ✅ FIX 2: Circuit Breaker dengan auto-recovery.
//
//  Masalah lama: begitu Redis mati, HybridStorage terjebak
//  di mode degraded selamanya — bahkan setelah Redis pulih.
//  Aplikasi terus pakai fallback lokal (kurang akurat di
//  multi-server) tanpa pernah mencoba kembali ke Redis.
//
//  Solusi — tiga kondisi circuit breaker:
//
//    CLOSED  (normal)   → semua request ke primary (Redis)
//    OPEN    (degraded) → semua request ke fallback
//    HALF-OPEN          → setiap N detik, coba primary sekali
//                         • Berhasil → kembali ke CLOSED
//                         • Gagal    → tetap OPEN, reset timer
//
//  Parameter:
//    $retryInterval  Interval coba primary lagi (detik). Default 60s.
//                    Set lebih rendah (mis. 10s) untuk recovery cepat,
//                    tapi ini menambah overhead jika Redis terus mati.
// ═══════════════════════════════════════════════════════════

class HybridStorage implements StorageInterface
{
    private bool $degraded    = false;
    private int  $lastAttempt = 0;

    /**
     * @param StorageInterface $primary        Redis (terpusat, akurat)
     * @param StorageInterface $fallback       APCu atau FileStorage (lokal)
     * @param callable|null    $onDegrade      Dipanggil saat Redis pertama kali mati
     * @param callable|null    $onRecover      Dipanggil saat Redis pulih kembali
     * @param int              $retryInterval  Detik antar percobaan recovery (default 60)
     */
    public function __construct(
        private readonly StorageInterface $primary,
        private readonly StorageInterface $fallback,
        private readonly mixed            $onDegrade      = null,
        private readonly mixed            $onRecover      = null,
        private readonly int              $retryInterval  = 60
    ) {}

    public function get(string $key): ?array
    {
        if ($this->shouldTryPrimary()) {
            try {
                $result = $this->primary->get($key);
                $this->recover();
                return $result;
            } catch (\Throwable $e) {
                $this->enterDegradedMode($e);
                return $this->fallback->get($key);
            }
        }

        if ($this->degraded) {
            return $this->fallback->get($key);
        }

        try {
            return $this->primary->get($key);
        } catch (\Throwable $e) {
            $this->enterDegradedMode($e);
            return $this->fallback->get($key);
        }
    }

    public function set(string $key, array $data, int $ttl): void
    {
        if ($this->degraded && !$this->shouldTryPrimary()) {
            $this->fallback->set($key, $data, $ttl);
            return;
        }

        try {
            $this->primary->set($key, $data, $ttl);
            if ($this->degraded) {
                $this->recover();
            }
        } catch (\Throwable $e) {
            $this->enterDegradedMode($e);
            $this->fallback->set($key, $data, $ttl);
        }
    }

    public function delete(string $key): void
    {
        if ($this->degraded && !$this->shouldTryPrimary()) {
            $this->fallback->delete($key);
            return;
        }

        try {
            $this->primary->delete($key);
            if ($this->degraded) {
                $this->recover();
            }
        } catch (\Throwable $e) {
            $this->enterDegradedMode($e);
            $this->fallback->delete($key);
        }
    }

    /** Apakah sedang dalam mode degraded (Redis mati)? */
    public function isDegraded(): bool
    {
        return $this->degraded;
    }

    /**
     * Paksa coba kembali ke primary sekarang (untuk testing/admin).
     * Mengembalikan true jika primary berhasil dijangkau.
     */
    public function forceRetry(): bool
    {
        $this->lastAttempt = 0; // reset timer agar shouldTryPrimary() = true
        try {
            $this->primary->get('__ping__');
            $this->recover();
            return true;
        } catch (\Throwable $e) {
            $this->lastAttempt = time();
            return false;
        }
    }

    // ── Internals ─────────────────────────────────────────

    /**
     * Apakah waktunya mencoba primary lagi? (kondisi HALF-OPEN)
     * True jika: degraded DAN sudah lewat $retryInterval sejak percobaan terakhir.
     */
    private function shouldTryPrimary(): bool
    {
        return $this->degraded
            && (time() - $this->lastAttempt) >= $this->retryInterval;
    }

    private function enterDegradedMode(\Throwable $e): void
    {
        $this->lastAttempt = time();

        if (!$this->degraded) {
            $this->degraded = true;
            error_log('[RateLimiter:HybridStorage] Primary down, fallback aktif. Error: ' . $e->getMessage());

            if ($this->onDegrade !== null) {
                ($this->onDegrade)($e);
            }
        }
    }

    private function recover(): void
    {
        if ($this->degraded) {
            $this->degraded    = false;
            $this->lastAttempt = 0;
            error_log('[RateLimiter:HybridStorage] Primary pulih, kembali ke mode normal.');

            if ($this->onRecover !== null) {
                ($this->onRecover)();
            }
        }
    }
}


// ═══════════════════════════════════════════════════════════
//  ARRAY STORAGE  (Untuk testing / unit test)
// ═══════════════════════════════════════════════════════════

class ArrayStorage implements StorageInterface
{
    private array $store = [];
    private array $expiry = [];

    public function get(string $key): ?array
    {
        if (!isset($this->store[$key])) {
            return null;
        }

        if (isset($this->expiry[$key]) && time() > $this->expiry[$key]) {
            unset($this->store[$key], $this->expiry[$key]);
            return null;
        }

        return $this->store[$key];
    }

    public function set(string $key, array $data, int $ttl): void
    {
        $this->store[$key]  = $data;
        $this->expiry[$key] = time() + $ttl;
    }

    public function delete(string $key): void
    {
        unset($this->store[$key], $this->expiry[$key]);
    }
}
