<?php

declare(strict_types=1);

namespace RateLimiter;

/**
 * SecurityHelper
 *
 * Tambalan untuk celah keamanan yang tidak ditangani RateLimiter inti:
 *
 *  1. IPv6 /64 Subnet Normalization
 *     — Penyerang bisa punya jutaan IPv6 di satu /64 blok.
 *       Solusi: normalisasi ke prefix /64 sehingga seluruh blok dihitung bersama.
 *
 *  2. IP Whitelist / Blacklist statis
 *     — Server monitoring, CI/CD, admin internal harus bebas limit.
 *       Bot berbahaya yang sudah diketahui langsung ditolak.
 *
 *  3. Fail-Safe / Fail-Open wrapper
 *     — Jika storage Redis/File crash, default behavior tidak
 *       menyebabkan seluruh aplikasi mati. Bisa fail-open (izinkan)
 *       atau fail-closed (tolak) sesuai kebijakan.
 *
 *  4. Captcha Threshold
 *     — Sebelum blokir penuh, berikan sinyal untuk tampilkan CAPTCHA.
 */
class SecurityHelper
{
    // ─────────────────────────────────────────────
    //  1. IPv6 SUBNET NORMALIZATION
    // ─────────────────────────────────────────────

    /**
     * Normalisasi IP untuk dipakai sebagai identifier rate limit.
     *
     * - IPv4  → kembalikan apa adanya
     * - IPv6  → kembalikan prefix /64 (8 blok pertama dari 128 bit)
     *           sehingga seluruh blok /64 dihitung sebagai satu entitas
     *
     * Contoh:
     *   2001:db8:abcd:1234:ffff:ffff:ffff:0001
     *   → 2001:db8:abcd:1234::   (prefix /64)
     */
    public static function normalizeIp(string $ip): string
    {
        // Validasi dulu
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return $ip; // IPv4 tidak perlu normalisasi
        }

        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            return '0.0.0.0'; // IP tidak valid, kembalikan dummy
        }

        // Expand IPv6 ke bentuk penuh (isi :: dengan nol)
        $packed  = inet_pton($ip);
        $full    = bin2hex($packed); // 32 hex chars = 128 bit

        // Ambil 64 bit pertama (16 hex chars), sisanya nol
        $prefix  = substr($full, 0, 16) . str_repeat('0', 16);

        // Kemas kembali menjadi string IP
        $normalized = inet_ntop(hex2bin($prefix));

        // Tambah notasi /64 agar jelas ini adalah subnet
        return $normalized . '/64';
    }

    /**
     * Dapatkan IP klien yang sudah dinormalisasi untuk rate limiting.
     *
     * @param bool  $trustProxy   Aktifkan proxy header
     * @param array $trustedCidrs IP/CIDR proxy yang terpercaya (wajib jika trustProxy=true)
     */
    public static function normalizedClientIp(bool $trustProxy = false, array $trustedCidrs = []): string
    {
        $ip = RateLimiter::clientIp($trustProxy, $trustedCidrs);
        return self::normalizeIp($ip);
    }


    // ─────────────────────────────────────────────
    //  2. WHITELIST / BLACKLIST
    // ─────────────────────────────────────────────

    /**
     * Cek apakah IP ada dalam daftar (mendukung CIDR dan range).
     *
     * Contoh penggunaan:
     *   SecurityHelper::ipInList('10.0.0.5', ['10.0.0.0/24', '192.168.1.1'])
     */
    public static function ipInList(string $ip, array $list): bool
    {
        foreach ($list as $entry) {
            if (str_contains($entry, '/')) {
                // CIDR notation
                if (self::ipInCidr($ip, $entry)) {
                    return true;
                }
            } elseif ($ip === $entry) {
                return true;
            }
        }

        return false;
    }

    private static function ipInCidr(string $ip, string $cidr): bool
    {
        [$subnet, $bits] = explode('/', $cidr);
        $bits = (int) $bits;

        // IPv4
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
            && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
        ) {
            $ipLong     = ip2long($ip);
            $subnetLong = ip2long($subnet);
            $mask       = -1 << (32 - $bits);

            return ($ipLong & $mask) === ($subnetLong & $mask);
        }

        // IPv6
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)
            && filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)
        ) {
            $ipBin     = inet_pton($ip);
            $subnetBin = inet_pton($subnet);

            // Bandingkan $bits pertama
            $byteCount = (int) floor($bits / 8);
            $extraBits = $bits % 8;

            if (substr($ipBin, 0, $byteCount) !== substr($subnetBin, 0, $byteCount)) {
                return false;
            }

            if ($extraBits === 0) {
                return true;
            }

            $mask       = 0xFF & (0xFF << (8 - $extraBits));
            $ipByte     = ord($ipBin[$byteCount]);
            $subnetByte = ord($subnetBin[$byteCount]);

            return ($ipByte & $mask) === ($subnetByte & $mask);
        }

        return false;
    }


    // ─────────────────────────────────────────────
    //  3. FAIL-SAFE WRAPPER
    // ─────────────────────────────────────────────

    /**
     * Jalankan attempt() dengan proteksi jika storage crash.
     *
     * @param  bool  $failOpen  true  = izinkan request jika storage error
     *                          false = tolak request jika storage error (lebih aman)
     * @return bool
     */
    public static function safeAttempt(
        RateLimiter $limiter,
        string      $identifier,
        int         $limit    = 60,
        int         $window   = 60,
        int         $cost     = 1,
        bool        $failOpen = true,
        ?callable   $onError  = null
    ): bool {
        try {
            return $limiter->attempt($identifier, $limit, $window, $cost);
        } catch (\Throwable $e) {
            // Log error tanpa crash aplikasi
            if ($onError !== null) {
                $onError($e);
            } else {
                error_log('[RateLimiter] Storage error: ' . $e->getMessage());
            }

            // fail-open = true artinya izinkan (beri benefit of the doubt)
            // fail-closed = false artinya tolak (lebih konservatif)
            return $failOpen;
        }
    }


    // ─────────────────────────────────────────────
    //  4. CAPTCHA THRESHOLD  (diperbaiki)
    // ─────────────────────────────────────────────

    /**
     * Cek apakah user perlu CAPTCHA sebelum diblokir penuh.
     *
     * ✅ FIX: Bug logika di versi sebelumnya:
     *   - getRemaining() dipanggil SEBELUM attempt() → nilai stale
     *   - Kalkulasi softRemaining bisa negatif / salah
     *   - attempt() dipanggil di awal → selalu menghabiskan kuota
     *     bahkan saat hasilnya 'captcha' atau 'blocked'
     *
     * Logika yang benar:
     *   1. check() dulu tanpa increment → hitung posisi saat ini
     *   2. Putuskan: ok / captcha / blocked berdasarkan posisi
     *   3. attempt() hanya dipanggil jika keputusannya 'ok'
     *
     * @return string  'ok' | 'captcha' | 'blocked'
     */
    public static function checkWithCaptcha(
        RateLimiter $limiter,
        string      $identifier,
        int         $hardLimit = 10,
        int         $softLimit = 6,   // CAPTCHA mulai dari sini
        int         $window    = 60
    ): string {
        if ($softLimit >= $hardLimit) {
            throw new \InvalidArgumentException('softLimit harus lebih kecil dari hardLimit.');
        }

        // LANGKAH 1: Baca state saat ini TANPA menambah counter
        $limiter->check($identifier, $hardLimit, $window);
        $used = $hardLimit - $limiter->getRemaining(); // sudah digunakan

        // LANGKAH 2: Putuskan berdasarkan posisi
        if ($used >= $hardLimit) {
            return 'blocked'; // Sudah penuh — tolak tanpa menambah counter
        }

        if ($used >= $softLimit) {
            return 'captcha'; // Zona peringatan — tampilkan CAPTCHA dulu
        }

        // LANGKAH 3: Baru tambah counter hanya jika 'ok'
        $limiter->attempt($identifier, $hardLimit, $window);
        return 'ok';
    }


    // ─────────────────────────────────────────────
    //  5. GLOBAL RATE LIMIT (Anti Distributed Attack)
    // ─────────────────────────────────────────────

    /**
     * Terapkan global rate limit di endpoint tertentu.
     *
     * MASALAH: Rate limit per-IP tidak efektif melawan botnet.
     *   Server A: 59 req (lolos) + Server B: 59 req (lolos) = 118 req
     *   Padahal limit 60/menit.
     *
     * SOLUSI: Tambahkan counter global untuk endpoint kritis.
     *   Semua request ke /login dihitung bersama, apapun IP-nya.
     *   Ini butuh RedisStorage agar akurat di multi-server.
     *
     * Cara pakai:
     *   // Di awal handler /login:
     *   if (!SecurityHelper::globalAttempt($limiter, 'login', 1000, 60)) {
     *       die('Server sedang dalam tekanan tinggi. Coba lagi nanti.');
     *   }
     *   // Lanjut ke rate limit per-IP seperti biasa
     *
     * @param string $endpoint   Nama endpoint (misal: 'login', 'search')
     * @param int    $limit      Maksimum request global per $window
     * @param int    $window     Jendela waktu dalam detik
     * @return bool  false = endpoint sedang overloaded
     */
    public static function globalAttempt(
        RateLimiter $limiter,
        string      $endpoint,
        int         $limit  = 1000,
        int         $window = 60
    ): bool {
        // Prefix 'global:' memisahkan dari counter per-user
        return $limiter->attempt('global:' . $endpoint, $limit, $window);
    }

    /**
     * Cek saja global rate limit tanpa menambah counter.
     * Berguna untuk monitoring / health check.
     */
    public static function globalCheck(
        RateLimiter $limiter,
        string      $endpoint,
        int         $limit  = 1000,
        int         $window = 60
    ): int {
        $limiter->check('global:' . $endpoint, $limit, $window);
        return $limiter->getRemaining();
    }
}
