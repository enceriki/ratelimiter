<?php

declare(strict_types=1);

namespace RateLimiter;

/**
 * RateLimiter - Handal, Aman, dan Framework-Agnostic
 *
 * Mendukung dua algoritma yang bisa dipilih per-instance:
 *
 *   'dual-counter' (default)
 *      Sliding Window dua counter — O(1), sangat ringan.
 *      Cocok: API publik, endpoint umum, traffic tinggi.
 *      Trade-off: estimasi, bisa lolos sebelum retry_after habis.
 *
 *   'timestamp'
 *      Timestamp per-request — akurat, hard blocking.
 *      Cocok: login, OTP, transfer, endpoint sensitif.
 *      Trade-off: O(n), lebih berat (max ~500 req/window untuk FileStorage).
 *
 * Contoh pemakaian:
 *   // Untuk login — ketat
 *   $loginLimiter = new RateLimiter($storage, ['algorithm' => 'timestamp']);
 *
 *   // Untuk API — ringan
 *   $apiLimiter = new RateLimiter($storage, ['algorithm' => 'dual-counter']);
 *
 *   // Ganti algoritma setelah konstruksi
 *   $limiter->setAlgorithm('timestamp');
 */
class RateLimiter
{
    // Konstanta algoritma — hindari typo string
    const ALGO_TIMESTAMP    = 'timestamp';
    const ALGO_DUAL_COUNTER = 'dual-counter';

    // Konstanta log level — untuk writeLog()
    const LOG_LEVEL_INFO  = 'INFO';
    const LOG_LEVEL_WARN  = 'WARN';
    const LOG_LEVEL_BLOCK = 'BLOCK';

    // ✅ FIX 7: Batas atas counter violation (cegah pertumbuhan tak terbatas)
    // Nilai 100.000 = "serangan serius" untuk keperluan alerting/monitoring
    const MAX_VIOLATION_COUNT = 100_000;

    // ✅ SOLUSI 2: Prefix pendek untuk isolasi key per algoritma di storage.
    // Digunakan oleh buildKey() saat dipanggil dari method counter.
    // Sengaja dibuat pendek (2 karakter) agar key storage tidak terlalu panjang.
    //   'ts' = timestamp
    //   'dc' = dual-counter
    const KEY_PREFIX_TIMESTAMP    = 'ts';
    const KEY_PREFIX_DUAL_COUNTER = 'dc';

    // ✅ FIX 1: Batas atas limit untuk algoritma timestamp
    // Di atas nilai ini, timestamp menjadi terlalu berat (O(n) per request)
    // dan berisiko under-count jika storage terlambat menulis.
    // Gunakan dual-counter untuk limit > nilai ini.
    const TIMESTAMP_MAX_LIMIT = 500;

    private StorageInterface $storage;
    private array            $config;
    private string           $algorithm = self::ALGO_DUAL_COUNTER;

    // Status terakhir setelah pengecekan
    private int $remaining  = 0;
    private int $resetAt    = 0;
    private int $retryAfter = 0;

    public function __construct(StorageInterface $storage, array $config = [])
    {
        $this->storage   = $storage;
        $this->config    = array_merge($this->defaultConfig(), $config);
        $this->algorithm = $this->resolveAlgorithm($this->config['algorithm'] ?? self::ALGO_DUAL_COUNTER);
    }

    /**
     * Ganti algoritma setelah konstruksi.
     * Return $this untuk method chaining.
     */
    public function setAlgorithm(string $algorithm): static
    {
        $this->algorithm = $this->resolveAlgorithm($algorithm);
        return $this;
    }

    public function getAlgorithm(): string
    {
        return $this->algorithm;
    }

    // ─────────────────────────────────────────────
    //  PUBLIC API
    // ─────────────────────────────────────────────

    /**
     * Cek apakah request boleh dilanjutkan.
     *
     * Algoritma dipilih dari config constructor atau setAlgorithm().
     * Semua parameter lain sama untuk kedua algoritma.
     *
     * @param  string  $identifier  Kunci unik (IP, user_id, token, dst.)
     * @param  int     $limit       Maksimum request dalam $window detik
     * @param  int     $window      Jendela waktu dalam detik
     * @param  int     $cost        "Biaya" request ini (default 1)
     * @param  string|null $algorithm Override algoritma untuk attempt ini saja
     * @return bool    true = boleh, false = diblokir
     */
    public function attempt(
        string  $identifier,
        int     $limit     = 60,
        int     $window    = 60,
        int     $cost      = 1,
        ?string $algorithm = null
    ): bool {
        // ✅ FIX: Resolve algo DULU sebelum validasi.
        // Masalah lama: validateInputs() hanya cek $this->algorithm (default instance),
        // bukan algoritma yang di-override via parameter $algorithm.
        // Akibatnya attempt('id', 1000, 60, algorithm: 'timestamp') LOLOS validasi
        // meski timestamp dengan limit 1000 berbahaya (under-count + DoS storage).
        //
        // Solusi: resolve algo lebih awal, lalu teruskan ke validateInputs()
        // agar validasi TIMESTAMP_MAX_LIMIT selalu mengecek algo yang BENAR-BENAR dipakai.
        $algo = $algorithm !== null
            ? $this->resolveAlgorithm($algorithm)
            : $this->algorithm;

        $this->validateInputs($identifier, $limit, $window, $cost, $algo);

        return $algo === self::ALGO_TIMESTAMP
            ? $this->attemptTimestamp($identifier, $limit, $window, $cost)
            : $this->attemptDualCounter($identifier, $limit, $window, $cost);
    }

    /**
     * Cek tanpa mencatat — menggunakan algoritma yang sama dengan attempt().
     *
     * ⚠️  Catatan Timing: check() tidak memiliki timing normalization.
     * Untuk keputusan kritis gunakan attempt() langsung.
     *
     * @param  string|null $algorithm Override algoritma untuk check ini saja
     */
    public function check(
        string  $identifier,
        int     $limit     = 60,
        int     $window    = 60,
        ?string $algorithm = null
    ): bool {
        // ✅ FIX: Resolve algo dulu agar validasi TIMESTAMP_MAX_LIMIT
        // juga berlaku untuk override parameter (konsisten dengan attempt()).
        $algo = $algorithm !== null
            ? $this->resolveAlgorithm($algorithm)
            : $this->algorithm;

        $this->validateInputs($identifier, $limit, $window, cost: 1, effectiveAlgo: $algo);

        return $algo === self::ALGO_TIMESTAMP
            ? $this->checkTimestamp($identifier, $limit, $window)
            : $this->checkDualCounter($identifier, $limit, $window);
    }

    /**
     * Reset counter untuk identifier tertentu.
     * Tidak menghapus blokir manual — gunakan unblock() untuk itu.
     *
     * Catatan SOLUSI 2:
     * Karena key kini berbeda per algoritma, reset() harus menghapus
     * key KEDUA algoritma sekaligus. Alasannya:
     *
     *   Skenario nyata: user login sukses setelah 3 percobaan gagal.
     *   Kita panggil reset("login:ip:hash") untuk hapus counter.
     *   Jika hanya hapus key 'ts:...', tapi ada sisa data 'dc:...' dari
     *   sesi sebelumnya, counter "roh lama" masih ada di storage dan
     *   bisa membingungkan saat debugging atau monitoring.
     *
     * Trade-off:
     *   Dua delete() per reset() — dampak performa sangat kecil karena
     *   reset() hanya dipanggil saat event tertentu (login sukses, dll),
     *   bukan setiap request.
     */
    public function reset(string $identifier): void
    {
        // Hapus counter timestamp
        $this->storage->delete($this->buildKey($identifier, self::KEY_PREFIX_TIMESTAMP));
        $this->storage->delete($this->buildKey($identifier, self::KEY_PREFIX_TIMESTAMP) . ':violations');

        // Hapus counter dual-counter
        $this->storage->delete($this->buildKey($identifier, self::KEY_PREFIX_DUAL_COUNTER));
        $this->storage->delete($this->buildKey($identifier, self::KEY_PREFIX_DUAL_COUNTER) . ':violations');
    }

    /**
     * Cabut blokir manual yang sebelumnya dibuat oleh block().
     */
    public function unblock(string $identifier): void
    {
        $this->storage->delete($this->buildKey($identifier) . ':blocked');
        $this->writeLog(self::LOG_LEVEL_BLOCK, sprintf(
            'UNBLOCK id_hash=%s',
            substr(hash('sha256', $identifier), 0, 12)
        ));
    }

    /**
     * Reset counter DAN cabut blokir manual sekaligus.
     */
    public function resetAll(string $identifier): void
    {
        $this->reset($identifier);
        $this->unblock($identifier);
    }

    /**
     * Blokir identifier secara manual (misal: setelah deteksi fraud).
     * Setiap pemanggilan dicatat via writeLog() untuk audit trail.
     */
    public function block(string $identifier, int $seconds = 3600): void
    {
        $key = $this->buildKey($identifier) . ':blocked';

        $trace  = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2);
        $caller = isset($trace[1])
            ? ($trace[1]['file'] ?? 'unknown') . ':' . ($trace[1]['line'] ?? '?')
            : 'unknown';

        $this->storage->set($key, [
            'blocked_at' => $this->now(),
            'expires_at' => $this->now() + $seconds,
        ], $seconds);

        $this->writeLog(self::LOG_LEVEL_BLOCK, sprintf(
            'BLOCK id_hash=%s duration=%ds caller=%s',
            substr(hash('sha256', $identifier), 0, 12),
            $seconds,
            $caller
        ));
    }

    /**
     * Cek apakah identifier sedang diblokir secara manual.
     * Response time dinormalisasi ke ≥1ms untuk mencegah timing attack.
     */
    public function isBlocked(string $identifier): bool
    {
        $start = hrtime(true);
        $result = false;

        try {
            $key  = $this->buildKey($identifier) . ':blocked';
            $data = $this->storage->get($key);
            $result = $data !== null && ($data['expires_at'] ?? 0) > $this->now();
        } catch (\Throwable) {
            $result = false;
        } finally {
            // Normalisasi waktu respons ke minimal 1ms
            $elapsed = hrtime(true) - $start;
            $delay   = max(0, 1_000_000 - $elapsed);
            if ($delay > 0) usleep((int)($delay / 1000));
        }

        return $result;
    }

    /**
     * Buat array header X-RateLimit-* untuk dikirim ke klien.
     *
     * ✅ FIX 3: Header X-RateLimit-Algorithm dihapus dari default.
     *
     * Masalah: mengekspos algoritma memberi informasi kepada penyerang.
     * Jika mereka tahu pakai dual-counter, mereka bisa mengeksploitasi
     * toleransi estimasi (kirim request saat estimasi sedang turun).
     *
     * Solusi: sembunyikan secara default, ekspos hanya saat debug=true.
     * Header lain (Limit, Remaining, Reset) tetap dikirim karena
     * sudah merupakan standar RFC 6585 dan tidak memberi keuntungan
     * signifikan bagi penyerang.
     *
     * @param int  $limit  Batas maksimum request
     * @param bool $debug  Tambahkan header debug (termasuk algoritma)
     */
    public function getHeaders(int $limit, bool $debug = false): array
    {
        $headers = [
            'X-RateLimit-Limit'     => (string) $limit,
            'X-RateLimit-Remaining' => (string) $this->remaining,
            'X-RateLimit-Reset'     => (string) $this->resetAt,
            'Retry-After'           => (string) $this->retryAfter,
        ];

        // Header debug: hanya kirim jika diminta eksplisit
        // JANGAN aktifkan $debug=true di production
        if ($debug) {
            $headers['X-RateLimit-Algorithm'] = $this->algorithm;
            $headers['X-RateLimit-PHP-Bits']  = (string) PHP_INT_SIZE * 8;
        }

        return $headers;
    }

    public function getRemaining(): int  { return $this->remaining; }
    public function getResetAt(): int    { return $this->resetAt; }
    public function getRetryAfter(): int { return $this->retryAfter; }

    // ─────────────────────────────────────────────
    //  ALGORITMA 1: DUAL-COUNTER O(1)
    //
    //  ✅ FIX 2 (doc): Race condition Redis — tidak atomik.
    //    get() + set() adalah dua operasi terpisah. Pada traffic
    //    sangat tinggi dengan RedisStorage, dua request bersamaan
    //    bisa membaca data yang sama, lalu keduanya menulis →
    //    kehilangan update (under-count atau over-count).
    //    Solusi untuk RedisStorage + presisi ketat: gunakan Lua script.
    //    Untuk FileStorage (flock) dan APCu (apcu_entry): sudah atomik.
    //
    //  ✅ FIX 6 (doc): Akurasi ±1 di batas window.
    //    Estimasi round(prev * (1 - pos)) + curr bisa over/under ±1
    //    di sekitar pergantian window. Error relatif:
    //      limit=5   → error bisa 20% (tidak cocok untuk keamanan)
    //      limit=100  → error < 1% (umumnya dapat diterima)
    //    Untuk presisi mutlak (billing, keamanan): gunakan timestamp.
    // ─────────────────────────────────────────────

    private function attemptDualCounter(
        string $identifier,
        int    $limit,
        int    $window,
        int    $cost
    ): bool {
        // SOLUSI 2: Sertakan prefix 'dc' agar key dual-counter tidak pernah
        // bertabrakan dengan key timestamp meskipun identifier-nya sama.
        $key  = $this->buildKey($identifier, self::KEY_PREFIX_DUAL_COUNTER);
        $now  = $this->now();
        $slot = (int) floor($now / $window);

        $data = $this->storage->get($key) ?? $this->emptyCounter($slot);

        if ($slot > $data['slot'] + 1) {
            $data = $this->emptyCounter($slot);
        } elseif ($slot === $data['slot'] + 1) {
            $data['prev'] = $data['curr'];
            $data['curr'] = 0;
            $data['slot'] = $slot;
        }

        $position  = ($now % $window) / $window;
        $estimated = (int) round($data['prev'] * (1.0 - $position)) + $data['curr'];

        if ($estimated + $cost > $limit) {
            $this->resetAt    = ($slot * $window) + $window;
            $this->retryAfter = max(0, $this->resetAt - $now);
            $this->remaining  = 0;
            $this->recordViolation($key . ':violations', $now);
            return false;
        }

        $data['curr']    += $cost;
        $this->remaining  = max(0, $limit - $estimated - $cost);
        $this->resetAt    = ($slot * $window) + $window;
        $this->retryAfter = 0;

        $this->storage->set($key, $data, $window * 2 + 1);
        return true;
    }

    private function checkDualCounter(string $identifier, int $limit, int $window): bool
    {
        // SOLUSI 2: Prefix 'dc' — konsisten dengan attemptDualCounter().
        $key  = $this->buildKey($identifier, self::KEY_PREFIX_DUAL_COUNTER);
        $now  = $this->now();
        $slot = (int) floor($now / $window);

        $data = $this->storage->get($key) ?? $this->emptyCounter($slot);

        if ($slot > $data['slot'] + 1) {
            $data = $this->emptyCounter($slot);
        } elseif ($slot === $data['slot'] + 1) {
            $data['prev'] = $data['curr'];
            $data['curr'] = 0;
        }

        $position        = ($now % $window) / $window;
        $estimated       = (int) round($data['prev'] * (1.0 - $position)) + $data['curr'];
        $this->remaining = max(0, $limit - $estimated);
        return $estimated < $limit;
    }

    // ─────────────────────────────────────────────
    //  ALGORITMA 2: TIMESTAMP PER-REQUEST O(n)
    //
    //  ✅ FIX 1: Hapus pemotongan 500-elemen (under-counting bug).
    //  ✅ FIX 2 (doc): Race condition Redis — tidak atomik.
    //  ✅ FIX 4 (doc): Slot overflow — wajib PHP 64-bit.
    //
    //  Batas penggunaan:
    //    - Limit ≤ 500 req/window (dijaga oleh validateInputs)
    //    - Untuk limit > 500 → gunakan dual-counter
    //    - Redis + presisi mutlak → gunakan Lua script atomik
    //    - WAJIB PHP 64-bit agar slot tidak overflow (Y2K38)
    // ─────────────────────────────────────────────

    private function attemptTimestamp(
        string $identifier,
        int    $limit,
        int    $window,
        int    $cost
    ): bool {
        // SOLUSI 2: Prefix 'ts' agar key timestamp terpisah dari key dual-counter.
        // Ini mencegah Fatal Error ketika data dual-counter {slot,prev,curr}
        // terbaca oleh timestamp yang mengharapkan {requests:[...]}.
        $key    = $this->buildKey($identifier, self::KEY_PREFIX_TIMESTAMP);
        $now    = $this->now();
        $cutoff = $now - $window;

        $data = $this->storage->get($key) ?? $this->emptyBucket($now, $window);

        // Bersihkan yang sudah expired.
        // FIX 1: TIDAK ada pemotongan tambahan di sini.
        // Pemotongan menyebabkan under-counting: jika 600 request valid
        // dalam window dan kita potong ke 500, 100 request awal hilang
        // dari hitungan → user bisa melebihi limit tanpa terdeteksi.
        // Batas atas dijaga oleh validateInputs() yang menolak limit > 500.
        $data['requests'] = array_values(
            array_filter($data['requests'], fn($r) => $r['ts'] > $cutoff)
        );

        $used = (int) array_sum(array_column($data['requests'], 'cost'));

        if ($used + $cost > $limit) {
            // Blokir keras — hitung kapan request tertua akan expired
            $oldest           = $data['requests'][0]['ts'] ?? $now;
            $this->resetAt    = $oldest + $window;
            $this->retryAfter = max(0, $this->resetAt - $now);
            $this->remaining  = 0;
            $this->recordViolation($key . ':violations', $now);
            return false;
        }

        $data['requests'][] = ['ts' => $now, 'cost' => $cost];
        $this->remaining    = max(0, $limit - $used - $cost);
        $this->resetAt      = $now + $window;
        $this->retryAfter   = 0;

        $this->storage->set($key, $data, $window + 1);
        return true;
    }

    private function checkTimestamp(string $identifier, int $limit, int $window): bool
    {
        // SOLUSI 2: Prefix 'ts' — konsisten dengan attemptTimestamp().
        $key    = $this->buildKey($identifier, self::KEY_PREFIX_TIMESTAMP);
        $now    = $this->now();
        $cutoff = $now - $window;

        $data = $this->storage->get($key) ?? $this->emptyBucket($now, $window);

        $valid = array_filter($data['requests'], fn($r) => $r['ts'] > $cutoff);
        $used  = (int) array_sum(array_column($valid, 'cost'));

        $this->remaining = max(0, $limit - $used);
        return $used < $limit;
    }

    // ─────────────────────────────────────────────
    //  IP RESOLVER (anti-spoofing)
    // ─────────────────────────────────────────────

    /**
     * Dapatkan IP klien yang aman dari spoofing.
     * Header proxy hanya dipercaya jika REMOTE_ADDR cocok dengan $trustedCidrs.
     */
    public static function clientIp(bool $trustProxy = false, array $trustedCidrs = []): string
    {
        $remoteAddr = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        if ($trustProxy && !empty($trustedCidrs)) {
            if (self::ipInCidrList($remoteAddr, $trustedCidrs)) {
                $headers = [
                    'HTTP_CF_CONNECTING_IP',
                    'HTTP_X_REAL_IP',
                    'HTTP_X_FORWARDED_FOR',
                ];

                foreach ($headers as $header) {
                    if (!empty($_SERVER[$header])) {
                        $ip = trim(explode(',', $_SERVER[$header])[0]);
                        if (filter_var($ip, FILTER_VALIDATE_IP)) {
                            return $ip;
                        }
                    }
                }
            }
        }

        return $remoteAddr;
    }

    /**
     * Buat fingerprint unik dari request (IP + User-Agent + Accept-Language).
     */
    public static function requestFingerprint(bool $trustProxy = false, array $trustedCidrs = []): string
    {
        $parts = [
            self::clientIp($trustProxy, $trustedCidrs),
            $_SERVER['HTTP_USER_AGENT']      ?? '',
            $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '',
            $_SERVER['HTTP_ACCEPT_ENCODING'] ?? '',
        ];

        return hash('sha256', implode('|', $parts));
    }

    // ─────────────────────────────────────────────
    //  INTERNAL
    // ─────────────────────────────────────────────

    private function resolveAlgorithm(string $algo): string
    {
        $valid = [self::ALGO_TIMESTAMP, self::ALGO_DUAL_COUNTER];
        if (!in_array($algo, $valid, true)) {
            throw new \InvalidArgumentException(
                "Algoritma '{$algo}' tidak dikenal. Pilih: " . implode(', ', $valid)
            );
        }
        return $algo;
    }

    /**
     * Buat key storage dari identifier.
     *
     * ✅ SOLUSI 2 — Isolasi Key per Algoritma:
     *
     * Masalah sebelumnya:
     *   Dua algoritma (timestamp & dual-counter) menggunakan KEY yang SAMA
     *   di storage. Jika satu endpoint pernah menggunakan dual-counter lalu
     *   berganti ke timestamp (atau file berbeda menggunakan storage yang sama),
     *   data yang dibaca memiliki struktur yang SALAH:
     *     dual-counter menyimpan: {slot, prev, curr}
     *     timestamp membaca    : {requests:[]} ← tidak ada → NULL → Fatal Error
     *
     * Solusi:
     *   Tambahkan prefix algoritma ke dalam key SEBELUM di-hash.
     *   Hasilnya:
     *     timestamp    → "ts:rl:sha256(identifier)"
     *     dual-counter → "dc:rl:sha256(identifier)"
     *
     *   Kedua key ini adalah DUA ENTRI BERBEDA di storage, tidak pernah
     *   saling baca atau saling timpa, meskipun identifier-nya sama persis.
     *
     * Catatan penting:
     *   $algo hanya diisi oleh method counter (attemptTimestamp, attemptDualCounter,
     *   checkTimestamp, checkDualCounter, recordViolation).
     *
     *   Method block(), unblock(), isBlocked() TIDAK melewatkan $algo,
     *   sehingga key blokir manual TIDAK memiliki prefix algoritma.
     *   Alasannya: blokir manual harus berlaku untuk identifier tersebut
     *   terlepas dari algoritma mana yang sedang dipakai.
     *
     * @param string      $identifier Kunci mentah (IP, user_id, email, dll)
     * @param string|null $algo       'ts' atau 'dc'. Null = tidak ada prefix algo.
     */
    private function buildKey(string $identifier, ?string $algo = null): string
    {
        $prefix = $this->config['key_prefix'];

        // Gabungkan prefix algoritma ke dalam identifier SEBELUM di-hash.
        // Ini memastikan identifier yang sama menghasilkan key yang berbeda
        // tergantung algoritma yang digunakan.
        //
        // Contoh dengan identifier "login:::1:abc123":
        //   timestamp    → hash("ts|login:::1:abc123") → "ts:rl:aef29..."
        //   dual-counter → hash("dc|login:::1:abc123") → "dc:rl:8b71c..."
        //   blokir manual → hash("login:::1:abc123")   → "rl:3fa2b...:blocked"
        //
        // Menggunakan | sebagai separator karena tidak mungkin muncul secara
        // tidak sengaja di dalam identifier biasa (IP, user_id, email).
        $toHash = $algo !== null ? "{$algo}|{$identifier}" : $identifier;
        $hashed = hash('sha256', $toHash);

        return "{$prefix}:{$hashed}";
    }

    private function emptyCounter(int $slot): array
    {
        return ['slot' => $slot, 'prev' => 0, 'curr' => 0];
    }

    private function emptyBucket(int $now, int $window): array
    {
        return ['requests' => [], 'window' => $window, 'created_at' => $now];
    }

    /**
     * Catat percobaan yang ditolak (untuk deteksi pola serangan).
     *
     * Catatan SOLUSI 2:
     * Parameter $key yang diterima di sini sudah mengandung prefix algoritma
     * karena dipanggil dari attemptTimestamp/attemptDualCounter dengan format:
     *   buildKey($identifier, $algoPrefix) . ':violations'
     *   → "ts:rl:sha256(id):violations"  (dari timestamp)
     *   → "dc:rl:sha256(id):violations"  (dari dual-counter)
     *
     * Ini berarti log violation juga terpisah per algoritma, yang justru
     * lebih baik untuk analisis: bisa dibedakan mana serangan ke endpoint
     * timestamp (login) vs endpoint dual-counter (API).
     */
    private function recordViolation(string $key, int $now): void
    {
        $data = $this->storage->get($key) ?? ['count' => 0, 'violations' => []];

        // ✅ FIX 7: Batasi pertumbuhan counter violation tanpa batas.
        //
        // Masalah lama: counter 'count' bertambah tanpa batas.
        // Penyerang yang mengirim 1 juta req/jam = counter 1 juta.
        // Dalam 24 jam = 24 juta. Secara teori bisa mencapai PHP_INT_MAX
        // (9.2×10^18 di 64-bit) tapi memakan storage dan membuat
        // monitoring tidak praktis ("berapa kali diblokir?" tidak berguna
        // jika nilainya 847.293.041).
        //
        // Solusi: cap counter di MAX_VIOLATION_COUNT (100.000).
        // Nilai ini cukup untuk alerting ("lebih dari 100k violation = serangan serius")
        // tanpa membiarkan nilai tidak terbatas.
        // TTL 3600 detik memastikan data lama otomatis dihapus dari storage.
        $count = ($data['count'] ?? 0) + 1;
        $data['count'] = min($count, self::MAX_VIOLATION_COUNT);

        $data['violations'][] = $now;
        if (count($data['violations']) > 100) {
            $data['violations'] = array_slice($data['violations'], -100);
        }

        $this->storage->set($key, $data, 3600);
    }

    /**
     * @param string      $identifier    Identifier yang divalidasi
     * @param int         $limit         Batas request
     * @param int         $window        Jendela waktu (detik)
     * @param int         $cost          Biaya per request
     * @param string|null $effectiveAlgo Algoritma yang BENAR-BENAR akan dipakai
     *                                   (bisa berbeda dari $this->algorithm jika di-override).
     *                                   Jika null, gunakan $this->algorithm.
     */
    private function validateInputs(
        string  $identifier,
        int     $limit,
        int     $window,
        int     $cost,
        ?string $effectiveAlgo = null
    ): void {
        if ($identifier === '') {
            throw new \InvalidArgumentException('Identifier tidak boleh kosong.');
        }
        if ($limit < 1) {
            throw new \InvalidArgumentException('Limit harus >= 1.');
        }
        if ($window < 1) {
            throw new \InvalidArgumentException('Window harus >= 1 detik.');
        }
        if ($cost < 1 || $cost > $limit) {
            throw new \InvalidArgumentException("Cost harus antara 1 dan {$limit}.");
        }

        // ✅ FIX: Gunakan $effectiveAlgo (algoritma yang benar-benar dipakai),
        // bukan $this->algorithm (default instance yang bisa di-override).
        // Ini mencegah bypass validasi TIMESTAMP_MAX_LIMIT via parameter override.
        //
        // Contoh yang dulu LOLOS (sekarang DITOLAK):
        //   $limiter = new RateLimiter($storage); // dual-counter
        //   $limiter->attempt('x', 1000, algorithm: 'timestamp'); // ← bypass!
        //
        // Sekarang: resolveAlgorithm() dipanggil di attempt()/check() SEBELUM
        // validateInputs(), lalu hasilnya diteruskan ke sini sebagai $effectiveAlgo.
        $algoUntukValidasi = $effectiveAlgo ?? $this->algorithm;

        if ($algoUntukValidasi === self::ALGO_TIMESTAMP && $limit > self::TIMESTAMP_MAX_LIMIT) {
            throw new \InvalidArgumentException(sprintf(
                'Algoritma timestamp hanya mendukung limit <= %d. ' .
                'Untuk limit %d, gunakan algoritma dual-counter.',
                self::TIMESTAMP_MAX_LIMIT,
                $limit
            ));
        }
    }

    private static function ipInCidrList(string $ip, array $list): bool
    {
        if (class_exists(SecurityHelper::class, false)) {
            return SecurityHelper::ipInList($ip, $list);
        }

        foreach ($list as $entry) {
            if (str_contains($entry, '/') && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                [$subnet, $bits] = explode('/', $entry, 2);
                if (filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    $bits = max(0, min(32, (int) $bits));
                    $mask = $bits > 0 ? (-1 << (32 - $bits)) : 0;
                    if ((ip2long($ip) & $mask) === (ip2long($subnet) & $mask)) {
                        return true;
                    }
                }
            } elseif ($ip === $entry) {
                return true;
            }
        }
        return false;
    }

    private function now(): int
    {
        return time();
    }

    /**
     * Tulis log ke file terpisah (bukan PHP error_log).
     *
     * Cara kerja:
     *   - Jika 'log_enabled' = false  → tidak tulis apapun.
     *   - Jika 'log_path'   = null    → fallback ke error_log() PHP.
     *   - Jika 'log_path'   = string  → tulis ke file tersebut.
     *     Format baris: [2025-04-18 12:00:00] [LEVEL] pesan
     *
     * Rotasi otomatis:
     *   Jika ukuran file > 'log_max_bytes', file lama diganti nama menjadi
     *   ratelimiter.log.1 (overwrite jika sudah ada), lalu file baru dibuat.
     *   Ini mencegah file log membesar tidak terbatas.
     *
     * @param string $level   Salah satu dari konstanta LOG_LEVEL_*
     * @param string $message Pesan log (tanpa newline)
     */
    private function writeLog(string $level, string $message): void
    {
        // Cek flag enable/disable — jika false, langsung keluar
        if (empty($this->config['log_enabled'])) {
            return;
        }

        $logPath = $this->config['log_path'] ?? null;

        // Jika tidak ada path → fallback ke error_log() PHP bawaan
        if ($logPath === null) {
            error_log("[RateLimiter:{$level}] {$message}");
            return;
        }

        // Pastikan folder tujuan ada, buat jika belum
        $dir = dirname($logPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, recursive: true);
        }

        // Rotasi: jika file sudah ada dan > log_max_bytes, backup dulu
        $maxBytes = (int)($this->config['log_max_bytes'] ?? 10 * 1024 * 1024);
        if ($maxBytes > 0 && is_file($logPath) && filesize($logPath) >= $maxBytes) {
            rename($logPath, $logPath . '.1'); // overwrite .1 jika ada
        }

        // Tulis baris log: [timestamp] [LEVEL] pesan
        $line = sprintf(
            "[%s] [%s] %s
",
            date('Y-m-d H:i:s'),
            $level,
            $message
        );

        // FILE_APPEND | LOCK_EX: append aman dari race condition
        file_put_contents($logPath, $line, FILE_APPEND | LOCK_EX);
    }

    private function defaultConfig(): array
    {
        return [
            'key_prefix' => 'rl',
            'algorithm'  => self::ALGO_DUAL_COUNTER,

            // ── Konfigurasi Logging ─────────────────────────────
            // 'log_enabled'  : true  = tulis log, false = nonaktif
            // 'log_path'     : path file log. null = pakai error_log() PHP.
            //                  Contoh: __DIR__ . '/../logs/ratelimiter.log'
            // 'log_max_bytes': rotasi otomatis jika file > ukuran ini.
            //                  Default 10MB. Set 0 untuk nonaktif rotasi.
            'log_enabled'   => false,
            'log_path'      => null,
            'log_max_bytes' => 10 * 1024 * 1024, // 10 MB
        ];
    }
}
