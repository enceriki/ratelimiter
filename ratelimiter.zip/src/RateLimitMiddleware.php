<?php

declare(strict_types=1);

namespace RateLimiter;

/**
 * RateLimitMiddleware
 *
 * Framework-agnostic middleware.
 * Bisa dipakai di:
 *   - PHP murni (lihat contoh di bawah)
 *   - Laravel  (daftarkan di app/Http/Kernel.php)
 *   - Slim 4   (gunakan sebagai PSR-15 middleware)
 *   - CodeIgniter, Yii, dsb. (panggil handle() manual)
 */
class RateLimitMiddleware
{
    private RateLimiter $limiter;
    private array $options;

    public function __construct(RateLimiter $limiter, array $options = [])
    {
        $this->limiter = $limiter;
        $this->options = array_merge([
            'limit'           => 60,    // max request
            'window'          => 60,    // per N detik
            'cost'            => 1,     // biaya per request
            // ✅ FIX 1: trust_proxy kini wajib disertai trusted_cidrs.
            // Tanpa trusted_cidrs, header proxy TIDAK dipercaya meskipun
            // trust_proxy=true — mencegah IP spoofing via header palsu.
            'trust_proxy'     => false,
            'trusted_cidrs'   => [],    // Contoh: ['127.0.0.1', '10.0.0.0/8']
            'use_fingerprint' => false, // gunakan fingerprint (IP+UA+Language)
            'key_prefix'      => '',    // prefix untuk isolasi per route
            'on_limit'        => null,  // callable($remaining, $resetAt, $retryAfter)
        ], $options);
    }

    /**
     * Entry point utama — panggil di awal request pipeline.
     *
     * @return bool  true = lanjutkan, false = blokir (header sudah di-set)
     */
    public function handle(): bool
    {
        $identifier = $this->resolveIdentifier();

        // Cek blokir manual
        if ($this->limiter->isBlocked($identifier)) {
            $this->sendBlockedResponse();
            return false;
        }

        $allowed = $this->limiter->attempt(
            $identifier,
            $this->options['limit'],
            $this->options['window'],
            $this->options['cost']
        );

        // Selalu kirim header informatif
        $this->sendHeaders();

        if (!$allowed) {
            $cb = $this->options['on_limit'];
            if (is_callable($cb)) {
                $cb(
                    $this->limiter->getRemaining(),
                    $this->limiter->getResetAt(),
                    $this->limiter->getRetryAfter()
                );
            } else {
                $this->sendTooManyResponse();
            }
            return false;
        }

        return true;
    }

    // ─────────────────────────────────────────────
    //  PRIVATE
    // ─────────────────────────────────────────────

    private function resolveIdentifier(): string
    {
        // ✅ FIX 1: trusted_cidrs sekarang diteruskan ke clientIp() dan
        // requestFingerprint(). Tanpa ini, trust_proxy=true tidak pernah
        // benar-benar aktif karena clientIp() butuh CIDR untuk verifikasi.
        $cidrs = $this->options['trusted_cidrs'];
        $proxy = $this->options['trust_proxy'];

        $base = $this->options['use_fingerprint']
            ? RateLimiter::requestFingerprint($proxy, $cidrs)
            : RateLimiter::clientIp($proxy, $cidrs);

        $prefix = $this->options['key_prefix'];
        return $prefix !== '' ? "{$prefix}:{$base}" : $base;
    }

    private function sendHeaders(): void
    {
        if (headers_sent()) {
            return;
        }

        foreach ($this->limiter->getHeaders($this->options['limit']) as $name => $value) {
            header("{$name}: {$value}");
        }
    }

    private function sendTooManyResponse(): void
    {
        if (!headers_sent()) {
            http_response_code(429);
            header('Content-Type: application/json; charset=utf-8');
        }

        echo json_encode([
            'error'       => 'Too Many Requests',
            'message'     => 'Terlalu banyak permintaan. Coba lagi nanti.',
            'retry_after' => $this->limiter->getRetryAfter(),
            'reset_at'    => $this->limiter->getResetAt(),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    private function sendBlockedResponse(): void
    {
        if (!headers_sent()) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
        }

        echo json_encode([
            'error'   => 'Forbidden',
            'message' => 'Akses Anda telah diblokir.',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}
